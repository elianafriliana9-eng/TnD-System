ALTER TABLE `checklist_categories` ADD `division_id` INT NULL AFTER `id`;

ALTER TABLE `checklist_categories` ADD FOREIGN KEY (`division_id`) REFERENCES `divisions`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
