-- ============================================
-- TRAINING MODULE - NEW SCHEMA
-- Tanggal: 21 Oktober 2025
-- Konsep: Training per Outlet (bukan per participant)
-- ============================================

-- 1. Tabel session evaluations (evaluasi per point)
CREATE TABLE IF NOT EXISTS training_evaluations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    point_id INT NOT NULL,
    rating ENUM('baik', 'cukup', 'kurang') NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (session_id) REFERENCES training_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (point_id) REFERENCES training_points(id) ON DELETE CASCADE,
    UNIQUE KEY unique_session_point (session_id, point_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Tabel training yang diberikan kepada staff
CREATE TABLE IF NOT EXISTS training_topics_delivered (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    topic TEXT NOT NULL,
    order_index INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (session_id) REFERENCES training_sessions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Tabel signatures (Staff, Leader, Trainer)
CREATE TABLE IF NOT EXISTS training_signatures (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    signature_type ENUM('staff', 'leader', 'trainer') NOT NULL,
    signer_name VARCHAR(255) NOT NULL,
    signer_position VARCHAR(255),
    signature_data TEXT,  -- Base64 signature image atau path
    signed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (session_id) REFERENCES training_sessions(id) ON DELETE CASCADE,
    UNIQUE KEY unique_session_signature (session_id, signature_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Update training_sessions table - add new fields (one by one to avoid IF NOT EXISTS issue)
ALTER TABLE training_sessions ADD COLUMN rating_summary JSON COMMENT 'Summary: {baik: 10, cukup: 5, kurang: 2}';
ALTER TABLE training_sessions ADD COLUMN percentage_baik DECIMAL(5,2) DEFAULT 0 COMMENT 'Percentage of Baik rating';
ALTER TABLE training_sessions ADD COLUMN percentage_cukup DECIMAL(5,2) DEFAULT 0 COMMENT 'Percentage of Cukup rating';
ALTER TABLE training_sessions ADD COLUMN percentage_kurang DECIMAL(5,2) DEFAULT 0 COMMENT 'Percentage of Kurang rating';

-- training_photos sudah OK, tidak perlu diubah

-- ============================================
-- MIGRATION NOTES
-- ============================================
-- 1. Tabel training_participants tidak dipakai lagi
-- 2. Tabel training_responses tidak dipakai lagi
-- 3. Gunakan training_evaluations untuk evaluasi per point
-- 4. Gunakan training_signatures untuk tanda tangan 3 pihak
-- 5. Gunakan training_topics_delivered untuk materi training

-- ============================================
-- SAMPLE DATA
-- ============================================

-- Example: Training Evaluations
-- INSERT INTO training_evaluations (session_id, point_id, rating, notes) VALUES
-- (1, 1, 'baik', 'Area kasir sangat bersih'),
-- (1, 2, 'cukup', 'Area display perlu sedikit perbaikan'),
-- (1, 3, 'kurang', 'Greeting masih kurang ramah');

-- Example: Training Topics Delivered
-- INSERT INTO training_topics_delivered (session_id, topic, order_index) VALUES
-- (1, 'Teknik greeting customer yang baik', 1),
-- (1, 'Standar kebersihan outlet', 2),
-- (1, 'Prosedur handling complaint', 3);

-- Example: Signatures
-- INSERT INTO training_signatures (session_id, signature_type, signer_name, signer_position) VALUES
-- (1, 'staff', 'Budi Santoso', 'Store Manager'),
-- (1, 'leader', 'Ahmad Yani', 'Area Manager'),
-- (1, 'trainer', 'Siti Nurhaliza', 'Training Specialist');

-- ============================================
-- QUERY EXAMPLES
-- ============================================

-- Get session with evaluations
-- SELECT 
--     ts.*,
--     COUNT(DISTINCT te.id) as total_evaluations,
--     SUM(CASE WHEN te.rating = 'baik' THEN 1 ELSE 0 END) as count_baik,
--     SUM(CASE WHEN te.rating = 'cukup' THEN 1 ELSE 0 END) as count_cukup,
--     SUM(CASE WHEN te.rating = 'kurang' THEN 1 ELSE 0 END) as count_kurang,
--     ROUND(SUM(CASE WHEN te.rating = 'baik' THEN 1 ELSE 0 END) * 100.0 / COUNT(te.id), 2) as percentage_baik
-- FROM training_sessions ts
-- LEFT JOIN training_evaluations te ON ts.id = te.session_id
-- WHERE ts.id = 1
-- GROUP BY ts.id;

-- Get evaluation details by category
-- SELECT 
--     tcat.name as category_name,
--     tp.question as point_text,
--     te.rating,
--     te.notes
-- FROM training_evaluations te
-- JOIN training_points tp ON te.point_id = tp.id
-- JOIN training_categories tcat ON tp.category_id = tcat.id
-- WHERE te.session_id = 1
-- ORDER BY tcat.order_index, tp.order_index;

-- Get all signatures for a session
-- SELECT * FROM training_signatures WHERE session_id = 1;

-- Get training topics delivered
-- SELECT * FROM training_topics_delivered WHERE session_id = 1 ORDER BY order_index;
