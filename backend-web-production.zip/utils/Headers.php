<?php
/**
 * Headers Utility Class
 * TND System - PHP Native Version
 */

class Headers {
    
    /**
     * Set CORS headers for API responses
     */
    public static function setCORS($origin = '*', $methods = 'GET, POST, PUT, DELETE, OPTIONS', $headers = 'Content-Type, Authorization, X-Requested-With') {
        header("Access-Control-Allow-Origin: $origin");
        header("Access-Control-Allow-Methods: $methods");
        header("Access-Control-Allow-Headers: $headers");
        header('Access-Control-Allow-Credentials: true');
    }
    
    /**
     * Handle OPTIONS preflight request
     */
    public static function handlePreflight($origin = '*', $methods = 'GET, POST, PUT, DELETE, OPTIONS', $headers = 'Content-Type, Authorization, X-Requested-With') {
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            self::setCORS($origin, $methods, $headers);
            http_response_code(200);
            exit(0);
        }
    }
    
    /**
     * Set JSON content type
     */
    public static function setJSON() {
        header('Content-Type: application/json; charset=utf-8');
    }
    
    /**
     * Set common API headers
     */
    public static function setAPIHeaders($origin = '*') {
        self::setCORS($origin);
        self::setJSON();
        self::handlePreflight($origin);
    }
    
    /**
     * Set no-cache headers
     */
    public static function setNoCache() {
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
    }
}
?>