<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$response = [
    'test' => 'API Debug Test',
    'timestamp' => date('Y-m-d H:i:s'),
    'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    'php_version' => phpversion(),
    'method' => $_SERVER['REQUEST_METHOD'],
    'request_uri' => $_SERVER['REQUEST_URI'] ?? '',
];

// Test database connection
try {
    require_once __DIR__ . '/../config/env.php';
    
    $response['env_loaded'] = true;
    $response['db_host'] = $_ENV['DB_HOST'] ?? 'not set';
    $response['db_name'] = $_ENV['DB_NAME'] ?? 'not set';
    $response['db_user'] = $_ENV['DB_USERNAME'] ?? 'not set';
    
    // Try connection
    $dsn = "mysql:host={$_ENV['DB_HOST']};dbname={$_ENV['DB_NAME']};charset=utf8mb4";
    $pdo = new PDO($dsn, $_ENV['DB_USERNAME'], $_ENV['DB_PASSWORD']);
    
    $response['database_connection'] = 'SUCCESS ✅';
    $response['success'] = true;
    
} catch (Exception $e) {
    $response['env_loaded'] = false;
    $response['database_connection'] = 'FAILED ❌';
    $response['error'] = $e->getMessage();
    $response['success'] = false;
}

echo json_encode($response, JSON_PRETTY_PRINT);
?>
