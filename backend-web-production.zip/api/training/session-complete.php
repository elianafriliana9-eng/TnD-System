<?php
/**
 * Training Session - Mark as Complete
 * 
 * Marks a training session as completed and calculates final scores
 * 
 * @endpoint POST /api/training/session-complete.php
 * @auth Required (Trainer role)
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../../config/database.php';
require_once '../../utils/Auth.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!Auth::checkAuth()) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Authentication required'
    ]);
    exit();
}

$auth = [
    'user_id' => Auth::id(),
    'role' => Auth::user()['role'] ?? null
];

// Only POST method allowed
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed'
    ]);
    exit();
}

// Get request body
$input = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($input['session_id'])) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Missing required field: session_id'
    ]);
    exit();
}

$session_id = $input['session_id'];
$end_time = isset($input['end_time']) ? $input['end_time'] : date('H:i:s');
$trainer_notes = isset($input['trainer_notes']) ? $input['trainer_notes'] : null;
$checklist_id = isset($input['checklist_id']) ? $input['checklist_id'] : null; // Allow updating checklist

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Verify session exists and user has access
    $stmt = $conn->prepare("
        SELECT ts.*, tc.checklist_name, u.full_name as trainer_name
        FROM training_sessions ts
        JOIN training_checklists tc ON ts.checklist_id = tc.id
        JOIN users u ON ts.trainer_id = u.id
        WHERE ts.id = ?
    ");
    $stmt->execute([$session_id]);
    $session = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$session) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'Training session not found'
        ]);
        exit();
    }
    
    // Check if already completed
    if ($session['status'] === 'completed') {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Session is already completed'
        ]);
        exit();
    }
    
    // Only trainer who created session or admin can complete
    if ($auth['role'] !== 'super_admin' && 
        $auth['role'] !== 'admin' && 
        $session['trainer_id'] != $auth['user_id']) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'You do not have permission to complete this session'
        ]);
        exit();
    }
    
    // Begin transaction
    $conn->beginTransaction();
    
    // Calculate rating percentages from evaluations
    $stmt = $conn->prepare("
        SELECT 
            rating,
            COUNT(*) as count
        FROM training_evaluations
        WHERE session_id = ?
        GROUP BY rating
    ");
    $stmt->execute([$session_id]);
    $ratings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $totalPoints = 0;
    $countBaik = 0;
    $countCukup = 0;
    $countKurang = 0;
    
    foreach ($ratings as $rating) {
        $totalPoints += $rating['count'];
        
        switch ($rating['rating']) {
            case 'baik':
                $countBaik = $rating['count'];
                break;
            case 'cukup':
                $countCukup = $rating['count'];
                break;
            case 'kurang':
                $countKurang = $rating['count'];
                break;
        }
    }
    
    // Check if there are evaluations
    if ($totalPoints == 0) {
        $conn->rollBack();
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Cannot complete session without evaluations'
        ]);
        exit();
    }
    
    // Calculate percentages
    $percentageBaik = $totalPoints > 0 ? round(($countBaik / $totalPoints) * 100, 2) : 0;
    $percentageCukup = $totalPoints > 0 ? round(($countCukup / $totalPoints) * 100, 2) : 0;
    $percentageKurang = $totalPoints > 0 ? round(($countKurang / $totalPoints) * 100, 2) : 0;
    
    // Prepare rating summary JSON
    $ratingSummary = json_encode([
        'total_points' => $totalPoints,
        'baik' => [
            'count' => $countBaik,
            'percentage' => $percentageBaik
        ],
        'cukup' => [
            'count' => $countCukup,
            'percentage' => $percentageCukup
        ],
        'kurang' => [
            'count' => $countKurang,
            'percentage' => $percentageKurang
        ]
    ]);
    
    // Calculate overall average score (baik=100, cukup=50, kurang=0)
    $averageScore = round((($countBaik * 100) + ($countCukup * 50)) / $totalPoints, 2);
    
    // Update session to completed
    $updateSql = "
        UPDATE training_sessions 
        SET 
            status = 'completed',
            end_time = ?,
            trainer_notes = ?,
            average_score = ?,
            rating_summary = ?,
            percentage_baik = ?,
            percentage_cukup = ?,
            percentage_kurang = ?,
            completed_at = NOW(),
            updated_at = NOW()";
    
    $params = [
        $end_time,
        $trainer_notes,
        $averageScore,
        $ratingSummary,
        $percentageBaik,
        $percentageCukup,
        $percentageKurang
    ];
    
    // Add checklist_id update if provided
    if ($checklist_id !== null) {
        $updateSql .= ", checklist_id = ?";
        $params[] = $checklist_id;
    }
    
    $updateSql .= " WHERE id = ?";
    $params[] = $session_id;
    
    $update_stmt = $conn->prepare($updateSql);
    $update_stmt->execute($params);
    
    // Commit transaction
    $conn->commit();
    
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Training session completed successfully',
        'data' => [
            'session_id' => $session_id,
            'session_date' => $session['session_date'],
            'start_time' => $session['start_time'],
            'end_time' => $end_time,
            'checklist_name' => $session['checklist_name'],
            'trainer_name' => $session['trainer_name'],
            'trainer_notes' => $trainer_notes,
            'summary' => [
                'total_points' => $totalPoints,
                'average_score' => $averageScore,
                'baik' => [
                    'count' => $countBaik,
                    'percentage' => $percentageBaik
                ],
                'cukup' => [
                    'count' => $countCukup,
                    'percentage' => $percentageCukup
                ],
                'kurang' => [
                    'count' => $countKurang,
                    'percentage' => $percentageKurang
                ]
            ],
            'completed_at' => date('Y-m-d H:i:s')
        ]
    ]);
    
} catch (PDOException $e) {
    if (isset($conn) && $conn->inTransaction()) {
        $conn->rollBack();
    }
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
