-- ============================================
-- TRAINING MODULE - SAMPLE DATA SEED (Simple Version)
-- Date: 20 Oktober 2025
-- ============================================

-- 1. Insert Sample Training Checklist
INSERT INTO training_checklists (name, description, is_active) VALUES
('InHouse Training Form - Hospitality & Service', 'Comprehensive training checklist for hospitality, work ethics, hygiene, and product knowledge', 1);

SET @checklist_id = LAST_INSERT_ID();

-- 2. Insert Training Categories
INSERT INTO training_categories (checklist_id, name, description, order_index) VALUES
(@checklist_id, 'NILAI HOSPITALITY', 'Evaluasi kemampuan hospitality staff', 1),
(@checklist_id, 'NILAI ETOS KERJA', 'Evaluasi etos kerja dan profesionalisme', 2),
(@checklist_id, 'HYGIENE DAN SANITASI', 'Evaluasi kebersihan dan sanitasi', 3),
(@checklist_id, 'PRODUCT KNOWLEDGE DAN LAYANAN', 'Evaluasi pengetahuan produk dan layanan', 4);

-- Get category IDs
SET @cat_hospitality = (SELECT id FROM training_categories WHERE checklist_id = @checklist_id AND name = 'NILAI HOSPITALITY');
SET @cat_etos = (SELECT id FROM training_categories WHERE checklist_id = @checklist_id AND name = 'NILAI ETOS KERJA');
SET @cat_hygiene = (SELECT id FROM training_categories WHERE checklist_id = @checklist_id AND name = 'HYGIENE DAN SANITASI');
SET @cat_product = (SELECT id FROM training_categories WHERE checklist_id = @checklist_id AND name = 'PRODUCT KNOWLEDGE DAN LAYANAN');

-- 3. Insert Training Points for Hospitality
INSERT INTO training_points (category_id, question, order_index) VALUES
(@cat_hospitality, 'Staff mengerti pentingnya hospitality', 1),
(@cat_hospitality, 'Selalu tubuh tegap dan ramah dalam menghadapi customer', 2),
(@cat_hospitality, 'Etika menyembut customer', 3),
(@cat_hospitality, 'Kemurnian dan senyap dalam memenuhi kebutuhan customer', 4),
(@cat_hospitality, 'Layanan terhadap customer', 5),
(@cat_hospitality, '3S (Senyum, Sapa, Salam)', 6);

-- 4. Insert Training Points for Etos Kerja
INSERT INTO training_points (category_id, question, order_index) VALUES
(@cat_etos, 'Attitude', 1),
(@cat_etos, 'Disiplin', 2),
(@cat_etos, 'Teliti', 3),
(@cat_etos, 'Skill', 4),
(@cat_etos, 'Inovatif', 5),
(@cat_etos, 'Tanggung Jawab', 6),
(@cat_etos, 'Profesionalisme', 7);

-- 5. Insert Training Points for Hygiene
INSERT INTO training_points (category_id, question, order_index) VALUES
(@cat_hygiene, 'Grooming - Kerapihan dengan, penampilan, serta perform', 1),
(@cat_hygiene, 'Preventif maintenance utensil & equipment', 2),
(@cat_hygiene, 'Performa kebersihan diri (Sisir, kebersihan kuku)', 3),
(@cat_hygiene, 'Kebersihan dan keselarasan lingkungan kerja', 4);

-- 6. Insert Training Points for Product Knowledge
INSERT INTO training_points (category_id, question, order_index) VALUES
(@cat_product, 'Mengerti produk yang dijual', 1),
(@cat_product, 'Mengerti cara penyajian produk', 2),
(@cat_product, 'Mampu menjelaskan menu kepada customer', 3),
(@cat_product, 'Update dengan menu baru', 4),
(@cat_product, 'Mengetahui standar operasional', 5);

-- ============================================
-- VERIFICATION
-- ============================================

-- Show created checklist
SELECT 
    tc.id,
    tc.name,
    tc.description,
    COUNT(DISTINCT tcat.id) as total_categories,
    COUNT(tp.id) as total_points
FROM training_checklists tc
LEFT JOIN training_categories tcat ON tc.id = tcat.checklist_id
LEFT JOIN training_points tp ON tcat.id = tp.category_id
WHERE tc.id = @checklist_id
GROUP BY tc.id;

SELECT 'Training sample data inserted successfully!' AS status;
