-- ============================================
-- TRAINING MODULE - SAMPLE DATA SEED
-- Date: 20 Oktober 2025
-- ============================================

-- 1. Insert Sample Training Checklist
INSERT INTO training_checklists (name, description, is_active) VALUES
('InHouse Training Form - Hospitality & Service', 'Comprehensive training checklist for hospitality, work ethics, hygiene, and product knowledge', 1);

SET @checklist_id = LAST_INSERT_ID();

-- 2. Insert Training Categories
INSERT INTO training_categories (checklist_id, name, description, order_index) VALUES
(@checklist_id, 'NILAI HOSPITALITY', 'Evaluasi kemampuan hospitality staff', 1),
(@checklist_id, 'NILAI ETOS KERJA', 'Evaluasi etos kerja dan profesionalisme', 2),
(@checklist_id, 'HYGIENE DAN SANITASI', 'Evaluasi kebersihan dan sanitasi', 3),
(@checklist_id, 'PRODUCT KNOWLEDGE DAN LAYANAN', 'Evaluasi pengetahuan produk dan layanan', 4);

-- Get category IDs
SET @cat_hospitality = (SELECT id FROM training_categories WHERE checklist_id = @checklist_id AND name = 'NILAI HOSPITALITY');
SET @cat_etos = (SELECT id FROM training_categories WHERE checklist_id = @checklist_id AND name = 'NILAI ETOS KERJA');
SET @cat_hygiene = (SELECT id FROM training_categories WHERE checklist_id = @checklist_id AND name = 'HYGIENE DAN SANITASI');
SET @cat_product = (SELECT id FROM training_categories WHERE checklist_id = @checklist_id AND name = 'PRODUCT KNOWLEDGE DAN LAYANAN');

-- 3. Insert Training Points for Hospitality
INSERT INTO training_points (category_id, question, order_index) VALUES
(@cat_hospitality, 'Staff mengerti pentingnya hospitality', 1),
(@cat_hospitality, 'Selalu tubuh tegap dan ramah dalam menghadapi customer', 2),
(@cat_hospitality, 'Etika menyembut customer', 3),
(@cat_hospitality, 'Kemurnian dan senyap dalam memenuhi kebutuhan customer', 4),
(@cat_hospitality, 'Layanan terhadap customer', 5),
(@cat_hospitality, '3S (Senyum, Sapa, Salam)', 6);

-- 4. Insert Training Points for Etos Kerja
INSERT INTO training_points (category_id, question, order_index) VALUES
(@cat_etos, 'Attitude', 1),
(@cat_etos, 'Disiplin', 2),
(@cat_etos, 'Teliti', 3),
(@cat_etos, 'Skill', 4),
(@cat_etos, 'Inovatif', 5),
(@cat_etos, 'Tanggung Jawab', 6),
(@cat_etos, 'Profesionalisme', 7);

-- 5. Insert Training Points for Hygiene
INSERT INTO training_points (category_id, question, order_index) VALUES
(@cat_hygiene, 'Grooming - Kerapihan dengan, penampilan, serta perform', 1),
(@cat_hygiene, 'Preventif maintenance utensil & equipment', 2),
(@cat_hygiene, 'Performa kebersihan diri (Sisir, kebersihan kuku)', 3),
(@cat_hygiene, 'Kebersihan dan keselarasan lingkungan kerja', 4);

-- 6. Insert Training Points for Product Knowledge
INSERT INTO training_points (category_id, question, order_index) VALUES
(@cat_product, 'Pemahaman staff tentang product yang dijual', 1),
(@cat_product, 'Mengetahui dan membuktikan program marketing', 2),
(@cat_product, 'Menguasai kegiatan pelanggan', 3),
(@cat_product, 'Kecepatan, ketepatan, dan efektivitas dalam melayani customer', 4),
(@cat_product, 'Komitmen terhadap layanan', 5);

-- 7. Create sample trainer user (if not exists)
INSERT INTO users (username, password, full_name, email, phone, role, specialization, trainer_bio, division_id, is_active)
SELECT 
    'trainer1', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password: password
    'John Trainer',
    'trainer@tnd.com',
    '081234567890',
    'trainer',
    'Hospitality & Service Excellence',
    'Expert trainer with 10+ years experience in hospitality industry',
    1,
    1
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'trainer1');

-- 8. Create sample training session (for demo)
INSERT INTO training_sessions (outlet_id, trainer_id, checklist_id, session_date, start_time, end_time, status, notes)
SELECT 
    1, -- outlet_id (adjust based on your outlets table)
    (SELECT id FROM users WHERE username = 'trainer1' LIMIT 1),
    @checklist_id,
    CURDATE(),
    '09:00:00',
    '11:30:00',
    'completed',
    'Training session berjalan dengan baik. Staff antusias dan kooperatif.'
WHERE EXISTS (SELECT 1 FROM outlets WHERE id = 1);

SET @sample_session_id = LAST_INSERT_ID();

-- 9. Add sample participants (if session was created)
INSERT INTO training_participants (session_id, staff_name, position, average_score, notes)
SELECT @sample_session_id, 'Ahmad Barista', 'Barista', 4.5, 'Sangat baik, cepat memahami'
WHERE @sample_session_id > 0
UNION ALL
SELECT @sample_session_id, 'Budi Santoso', 'Waiter', 4.2, 'Baik, perlu improve di product knowledge'
WHERE @sample_session_id > 0
UNION ALL
SELECT @sample_session_id, 'Citra Dewi', 'Cashier', 4.7, 'Excellent, sangat teliti'
WHERE @sample_session_id > 0
UNION ALL
SELECT @sample_session_id, 'Doni Pratama', 'Kitchen Staff', 4.0, 'Cukup baik, perlu latihan hygiene'
WHERE @sample_session_id > 0
UNION ALL
SELECT @sample_session_id, 'Eka Putri', 'Supervisor', 4.8, 'Outstanding, bisa jadi contoh'
WHERE @sample_session_id > 0;

-- 10. Add sample responses for first participant
INSERT INTO training_responses (session_id, training_point_id, participant_id, score, notes)
SELECT 
    @sample_session_id,
    tp.id,
    (SELECT id FROM training_participants WHERE session_id = @sample_session_id LIMIT 1),
    FLOOR(4 + (RAND() * 2)), -- Random score between 4-5
    CASE 
        WHEN RAND() > 0.7 THEN 'Sangat baik'
        WHEN RAND() > 0.4 THEN 'Memuaskan'
        ELSE NULL
    END
FROM training_points tp
INNER JOIN training_categories tc ON tp.category_id = tc.id
WHERE tc.checklist_id = @checklist_id
AND @sample_session_id > 0
LIMIT 10; -- Sample responses

-- 11. Update session statistics
UPDATE training_sessions
SET 
    total_staff = (SELECT COUNT(*) FROM training_participants WHERE session_id = @sample_session_id),
    average_score = (SELECT AVG(average_score) FROM training_participants WHERE session_id = @sample_session_id)
WHERE id = @sample_session_id;

-- ============================================
-- VERIFICATION QUERIES
-- ============================================

SELECT 'Sample data inserted successfully!' AS status;

SELECT 
    'Training Checklist Created' AS item,
    name,
    (SELECT COUNT(*) FROM training_categories WHERE checklist_id = id) AS categories,
    (SELECT COUNT(*) FROM training_points tp 
     INNER JOIN training_categories tc ON tp.category_id = tc.id 
     WHERE tc.checklist_id = training_checklists.id) AS total_points
FROM training_checklists
WHERE id = @checklist_id;

SELECT 
    'Sample Training Session' AS item,
    ts.id,
    o.name AS outlet,
    u.full_name AS trainer,
    ts.session_date,
    ts.total_staff,
    ts.average_score,
    ts.status
FROM training_sessions ts
LEFT JOIN outlets o ON ts.outlet_id = o.id
LEFT JOIN users u ON ts.trainer_id = u.id
WHERE ts.id = @sample_session_id;
