<?php
/**
 * Training Statistics Dashboard
 * 
 * Get comprehensive training statistics and trends
 * 
 * @endpoint GET /api/training/stats.php
 * @auth Required
 * @params outlet_id, trainer_id, date_from, date_to
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../../config/database.php';
require_once '../../classes/Database.php';
require_once '../../utils/Auth.php';

// Check authentication (DISABLED FOR DEMO - ENABLE IN PRODUCTION)
// if (!Auth::checkAuth()) {
//     http_response_code(401);
//     echo json_encode([
//         'success' => false,
//         'message' => 'Authentication required'
//     ]);
//     exit();
// }

// Get authenticated user info (default to demo user if not logged in)
$auth = [
    'authenticated' => true,
    'user_id' => Auth::id() ?? 1, // Default to user ID 1 if not logged in
    'role' => $_SESSION['user_role'] ?? 'admin'
];

// Only GET method allowed
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method not allowed'
    ]);
    exit();
}

try {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Check if training_sessions table exists
    $check_table = $conn->query("SHOW TABLES LIKE 'training_sessions'");
    if ($check_table->rowCount() === 0) {
        // Return empty statistics if table doesn't exist yet
        http_response_code(200);
        echo json_encode([
            'success' => true,
            'message' => 'Training module not initialized yet. Please run database migration.',
            'data' => [
                'period' => [
                    'from' => date('Y-m-d', strtotime('-30 days')),
                    'to' => date('Y-m-d'),
                    'days' => 31
                ],
                'summary' => [
                    'total_sessions' => 0,
                    'completed_sessions' => 0,
                    'in_progress_sessions' => 0,
                    'pending_sessions' => 0,
                    'total_participants' => 0,
                    'total_trainers' => 0,
                    'overall_average_score' => 0,
                    'total_photos' => 0,
                    'completion_rate' => 0
                ],
                'sessions_by_status' => (object)[],
                'daily_trend' => [],
                'top_trainers' => [],
                'top_outlets' => [],
                'top_checklists' => [],
                'score_distribution' => [],
                'recent_sessions' => []
            ]
        ]);
        exit();
    }
    
    // Get filter parameters
    $outlet_id = isset($_GET['outlet_id']) ? $_GET['outlet_id'] : null;
    $trainer_id = isset($_GET['trainer_id']) ? $_GET['trainer_id'] : null;
    $date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-d', strtotime('-30 days'));
    $date_to = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');
    
    // Build WHERE clause for filtering
    $where_clauses = ["ts.session_date BETWEEN ? AND ?"];
    $params = [$date_from, $date_to];
    
    if ($outlet_id) {
        $where_clauses[] = "ts.outlet_id = ?";
        $params[] = $outlet_id;
    }
    
    if ($trainer_id) {
        $where_clauses[] = "ts.trainer_id = ?";
        $params[] = $trainer_id;
    } else if ($auth['role'] === 'trainer') {
        // Trainers only see their own stats
        $where_clauses[] = "ts.trainer_id = ?";
        $params[] = $auth['user_id'];
    }
    
    $where_sql = "WHERE " . implode(" AND ", $where_clauses);
    
    // === OVERALL SUMMARY ===
    $summary_sql = "
        SELECT 
            COUNT(DISTINCT ts.id) as total_sessions,
            COUNT(DISTINCT CASE WHEN ts.status = 'completed' THEN ts.id END) as completed_sessions,
            COUNT(DISTINCT CASE WHEN ts.status = 'in_progress' THEN ts.id END) as in_progress_sessions,
            COUNT(DISTINCT CASE WHEN ts.status = 'pending' THEN ts.id END) as pending_sessions,
            COUNT(DISTINCT tp.id) as total_participants,
            COUNT(DISTINCT ts.trainer_id) as total_trainers,
            AVG(CASE WHEN ts.status = 'completed' THEN ts.average_score END) as overall_average_score,
            COUNT(tph.id) as total_photos
        FROM training_sessions ts
        LEFT JOIN training_participants tp ON ts.id = tp.session_id
        LEFT JOIN training_photos tph ON ts.id = tph.session_id
        $where_sql
    ";
    
    $summary_stmt = $conn->prepare($summary_sql);
    $summary_stmt->execute($params);
    $summary = $summary_stmt->fetch(PDO::FETCH_ASSOC);
    
    // === SESSIONS BY STATUS ===
    $status_sql = "
        SELECT 
            status,
            COUNT(*) as count
        FROM training_sessions ts
        $where_sql
        GROUP BY status
    ";
    
    $status_stmt = $conn->prepare($status_sql);
    $status_stmt->execute($params);
    $sessions_by_status = [];
    
    while ($row = $status_stmt->fetch(PDO::FETCH_ASSOC)) {
        $sessions_by_status[$row['status']] = (int)$row['count'];
    }
    
    // === DAILY TREND (Last 30 days) ===
    $trend_sql = "
        SELECT 
            DATE(ts.session_date) as date,
            COUNT(*) as sessions_count,
            AVG(CASE WHEN ts.status = 'completed' THEN ts.average_score END) as avg_score,
            COUNT(DISTINCT tp.id) as participants_count
        FROM training_sessions ts
        LEFT JOIN training_participants tp ON ts.id = tp.session_id
        $where_sql
        GROUP BY DATE(ts.session_date)
        ORDER BY date ASC
    ";
    
    $trend_stmt = $conn->prepare($trend_sql);
    $trend_stmt->execute($params);
    $daily_trend = [];
    
    while ($row = $trend_stmt->fetch(PDO::FETCH_ASSOC)) {
        $daily_trend[] = [
            'date' => $row['date'],
            'sessions_count' => (int)$row['sessions_count'],
            'avg_score' => $row['avg_score'] ? round((float)$row['avg_score'], 2) : null,
            'participants_count' => (int)$row['participants_count']
        ];
    }
    
    // === TOP TRAINERS ===
    // Check if specialization column exists
    $check_column = $conn->query("SHOW COLUMNS FROM users LIKE 'specialization'");
    $has_specialization = $check_column->rowCount() > 0;
    
    $specialization_field = $has_specialization ? "u.specialization" : "NULL as specialization";
    
    $trainers_sql = "
        SELECT 
            u.id,
            u.name as full_name,
            $specialization_field,
            COUNT(DISTINCT ts.id) as sessions_count,
            COUNT(DISTINCT CASE WHEN ts.status = 'completed' THEN ts.id END) as completed_count,
            AVG(CASE WHEN ts.status = 'completed' THEN ts.average_score END) as avg_score,
            COUNT(DISTINCT tp.id) as total_participants
        FROM users u
        JOIN training_sessions ts ON u.id = ts.trainer_id
        LEFT JOIN training_participants tp ON ts.id = tp.session_id
        $where_sql
        GROUP BY u.id
        ORDER BY completed_count DESC, avg_score DESC
        LIMIT 10
    ";
    
    $trainers_stmt = $conn->prepare($trainers_sql);
    $trainers_stmt->execute($params);
    $top_trainers = [];
    
    while ($row = $trainers_stmt->fetch(PDO::FETCH_ASSOC)) {
        $top_trainers[] = [
            'id' => (int)$row['id'],
            'name' => $row['full_name'],
            'specialization' => $row['specialization'],
            'sessions_count' => (int)$row['sessions_count'],
            'completed_count' => (int)$row['completed_count'],
            'avg_score' => $row['avg_score'] ? round((float)$row['avg_score'], 2) : 0,
            'total_participants' => (int)$row['total_participants']
        ];
    }
    
    // === TOP PERFORMING OUTLETS ===
    $outlets_sql = "
        SELECT 
            o.id,
            o.name as outlet_name,
            o.region as outlet_city,
            COUNT(DISTINCT ts.id) as sessions_count,
            AVG(CASE WHEN ts.status = 'completed' THEN ts.average_score END) as avg_score,
            COUNT(DISTINCT tp.id) as total_participants
        FROM outlets o
        JOIN training_sessions ts ON o.id = ts.outlet_id
        LEFT JOIN training_participants tp ON ts.id = tp.session_id
        $where_sql
        GROUP BY o.id
        ORDER BY avg_score DESC, sessions_count DESC
        LIMIT 10
    ";
    
    $outlets_stmt = $conn->prepare($outlets_sql);
    $outlets_stmt->execute($params);
    $top_outlets = [];
    
    while ($row = $outlets_stmt->fetch(PDO::FETCH_ASSOC)) {
        $top_outlets[] = [
            'id' => (int)$row['id'],
            'name' => $row['outlet_name'],
            'city' => $row['outlet_city'],
            'sessions_count' => (int)$row['sessions_count'],
            'avg_score' => $row['avg_score'] ? round((float)$row['avg_score'], 2) : 0,
            'total_participants' => (int)$row['total_participants']
        ];
    }
    
    // === MOST USED CHECKLISTS ===
    $checklists_sql = "
        SELECT 
            tc.id,
            tc.name as checklist_name,
            COUNT(DISTINCT ts.id) as usage_count,
            AVG(CASE WHEN ts.status = 'completed' THEN ts.average_score END) as avg_score
        FROM training_checklists tc
        JOIN training_sessions ts ON tc.id = ts.checklist_id
        $where_sql
        GROUP BY tc.id
        ORDER BY usage_count DESC
        LIMIT 10
    ";
    
    $checklists_stmt = $conn->prepare($checklists_sql);
    $checklists_stmt->execute($params);
    $top_checklists = [];
    
    while ($row = $checklists_stmt->fetch(PDO::FETCH_ASSOC)) {
        $top_checklists[] = [
            'id' => (int)$row['id'],
            'name' => $row['checklist_name'],
            'usage_count' => (int)$row['usage_count'],
            'avg_score' => $row['avg_score'] ? round((float)$row['avg_score'], 2) : 0
        ];
    }
    
    // === SCORE DISTRIBUTION ===
    $distribution_sql = "
        SELECT 
            CASE 
                WHEN average_score >= 4.5 THEN 'Excellent (4.5-5.0)'
                WHEN average_score >= 3.5 THEN 'Good (3.5-4.4)'
                WHEN average_score >= 2.5 THEN 'Average (2.5-3.4)'
                WHEN average_score >= 1.5 THEN 'Below Average (1.5-2.4)'
                ELSE 'Poor (1.0-1.4)'
            END as score_range,
            COUNT(*) as count
        FROM training_sessions ts
        $where_sql
        AND ts.status = 'completed'
        AND ts.average_score IS NOT NULL
        GROUP BY score_range
        ORDER BY MIN(average_score) DESC
    ";
    
    $distribution_stmt = $conn->prepare($distribution_sql);
    $distribution_stmt->execute($params);
    $score_distribution = [];
    
    while ($row = $distribution_stmt->fetch(PDO::FETCH_ASSOC)) {
        $score_distribution[] = [
            'range' => $row['score_range'],
            'count' => (int)$row['count']
        ];
    }
    
    // === RECENT COMPLETED SESSIONS ===
    $recent_sql = "
        SELECT 
            ts.id,
            ts.session_date,
            ts.average_score,
            tc.name as checklist_name,
            o.name as outlet_name,
            u.name as trainer_name,
            COUNT(DISTINCT tp.id) as participants_count
        FROM training_sessions ts
        JOIN training_checklists tc ON ts.checklist_id = tc.id
        JOIN outlets o ON ts.outlet_id = o.id
        JOIN users u ON ts.trainer_id = u.id
        LEFT JOIN training_participants tp ON ts.id = tp.session_id
        $where_sql
        AND ts.status = 'completed'
        GROUP BY ts.id
        ORDER BY ts.session_date DESC, ts.updated_at DESC
        LIMIT 5
    ";
    
    $recent_stmt = $conn->prepare($recent_sql);
    $recent_stmt->execute($params);
    $recent_sessions = [];
    
    while ($row = $recent_stmt->fetch(PDO::FETCH_ASSOC)) {
        $recent_sessions[] = [
            'id' => (int)$row['id'],
            'session_date' => $row['session_date'],
            'checklist_name' => $row['checklist_name'],
            'outlet_name' => $row['outlet_name'],
            'trainer_name' => $row['trainer_name'],
            'average_score' => round((float)$row['average_score'], 2),
            'participants_count' => (int)$row['participants_count']
        ];
    }
    
    // Build final response
    $response_data = [
        'period' => [
            'from' => $date_from,
            'to' => $date_to,
            'days' => ceil((strtotime($date_to) - strtotime($date_from)) / 86400) + 1
        ],
        'summary' => [
            'total_sessions' => (int)$summary['total_sessions'],
            'completed_sessions' => (int)$summary['completed_sessions'],
            'in_progress_sessions' => (int)$summary['in_progress_sessions'],
            'pending_sessions' => (int)$summary['pending_sessions'],
            'total_participants' => (int)$summary['total_participants'],
            'total_trainers' => (int)$summary['total_trainers'],
            'overall_average_score' => $summary['overall_average_score'] ? round((float)$summary['overall_average_score'], 2) : 0,
            'total_photos' => (int)$summary['total_photos'],
            'completion_rate' => $summary['total_sessions'] > 0 
                ? round(($summary['completed_sessions'] / $summary['total_sessions']) * 100, 2) 
                : 0
        ],
        'sessions_by_status' => empty($sessions_by_status) ? (object)[] : $sessions_by_status,
        'daily_trend' => $daily_trend,
        'top_trainers' => $top_trainers,
        'top_outlets' => $top_outlets,
        'top_checklists' => $top_checklists,
        'score_distribution' => $score_distribution,
        'recent_sessions' => $recent_sessions
    ];
    
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Training statistics retrieved successfully',
        'data' => $response_data
    ]);
    
} catch (PDOException $e) {
    error_log("Training Stats API - PDO Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage(),
        'error_details' => [
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ]
    ]);
} catch (Exception $e) {
    error_log("Training Stats API - General Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage(),
        'error_details' => [
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ]
    ]);
}
?>
