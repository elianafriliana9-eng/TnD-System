-- Create Trainer User
-- Email: trainer@tnd.com
-- Password: password

DELETE FROM users WHERE email = 'trainer@tnd.com';

INSERT INTO users (name, email, password, role, is_active) 
VALUES ('Trainer Demo', 'trainer@tnd.com', '$2y$12$9s3ackZTfm30EzIwk69Y5e1obdMgEjyactfLUjrZ5amLqIgUOD3pm', 'trainer', 1);

SELECT id, name, email, role FROM users WHERE email = 'trainer@tnd.com';
