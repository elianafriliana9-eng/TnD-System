<?php
/**
 * Save Training Checklist API
 * Create or update training checklist with categories and points
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/Response.php';
require_once __DIR__ . '/../../utils/Auth.php';
require_once __DIR__ . '/../../utils/Headers.php';

Headers::setAPIHeaders();

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Temporarily disabled for testing
// if (!Auth::checkAuth()) {
//     Response::unauthorized('Authentication required');
// }

// Only accept POST method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Response::error('Method not allowed', 405);
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (empty($input['name'])) {
        Response::error('Checklist name is required', 400);
    }
    
    if (empty($input['categories']) || !is_array($input['categories'])) {
        Response::error('At least one category is required', 400);
    }
    
    // Start transaction
    $db->beginTransaction();
    
    $checklistId = $input['id'] ?? null;
    
    if ($checklistId) {
        // Update existing checklist
        $sql = "UPDATE training_checklists 
                SET name = :name, 
                    description = :description, 
                    updated_at = NOW() 
                WHERE id = :id";
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':name' => $input['name'],
            ':description' => $input['description'] ?? '',
            ':id' => $checklistId
        ]);
        
        // Delete existing categories and points (will cascade)
        $sql = "DELETE FROM training_points WHERE category_id IN 
                (SELECT id FROM training_categories WHERE checklist_id = :checklist_id)";
        $stmt = $db->prepare($sql);
        $stmt->execute([':checklist_id' => $checklistId]);
        
        $sql = "DELETE FROM training_categories WHERE checklist_id = :checklist_id";
        $stmt = $db->prepare($sql);
        $stmt->execute([':checklist_id' => $checklistId]);
        
    } else {
        // Create new checklist
        $sql = "INSERT INTO training_checklists (name, description, is_active, created_at) 
                VALUES (:name, :description, 1, NOW())";
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':name' => $input['name'],
            ':description' => $input['description'] ?? ''
        ]);
        $checklistId = $db->lastInsertId();
    }
    
    // Insert categories and points
    $categoryOrder = 0;
    foreach ($input['categories'] as $category) {
        $categoryOrder++;
        
        // Insert category
        $sql = "INSERT INTO training_categories (checklist_id, name, order_index, created_at) 
                VALUES (:checklist_id, :name, :order_index, NOW())";
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':checklist_id' => $checklistId,
            ':name' => $category['name'],
            ':order_index' => $categoryOrder
        ]);
        $categoryId = $db->lastInsertId();
        
        // Insert points for this category
        if (!empty($category['points']) && is_array($category['points'])) {
            $pointOrder = 0;
            foreach ($category['points'] as $point) {
                $pointOrder++;
                
                $sql = "INSERT INTO training_points (category_id, question, order_index, created_at) 
                        VALUES (:category_id, :question, :order_index, NOW())";
                $stmt = $db->prepare($sql);
                $stmt->execute([
                    ':category_id' => $categoryId,
                    ':question' => $point,
                    ':order_index' => $pointOrder
                ]);
            }
        }
    }
    
    // Commit transaction
    $db->commit();
    
    // Get the complete checklist data
    $sql = "SELECT 
                tc.id,
                tc.name,
                tc.description,
                tc.is_active,
                tc.created_at,
                COUNT(DISTINCT tcat.id) as categories_count,
                COUNT(tp.id) as points_count
            FROM training_checklists tc
            LEFT JOIN training_categories tcat ON tc.id = tcat.checklist_id
            LEFT JOIN training_points tp ON tcat.id = tp.category_id
            WHERE tc.id = :id
            GROUP BY tc.id";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':id' => $checklistId]);
    $checklist = $stmt->fetch(PDO::FETCH_ASSOC);
    
    Response::success(
        $checklist, 
        $input['id'] ? 'Checklist updated successfully' : 'Checklist created successfully'
    );
    
} catch (Exception $e) {
    // Rollback on error
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    Response::error('Server error: ' . $e->getMessage(), 500);
}
