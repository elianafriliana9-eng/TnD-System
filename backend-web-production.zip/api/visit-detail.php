<?php
/**
 * Visit Detail API
 * Get complete visit details including responses and photos grouped properly
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../utils/Response.php';
require_once __DIR__ . '/../utils/Auth.php';
require_once __DIR__ . '/../utils/Headers.php';

// Handle preflight and set headers
Headers::setAPIHeaders();

// Start session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!Auth::checkAuth()) {
    Response::unauthorized('Authentication required');
}

try {
    if (!isset($_GET['visit_id'])) {
        Response::error('Visit ID required', 400);
    }
    
    $visitId = intval($_GET['visit_id']);
    $db = Database::getInstance()->getConnection();
    
    // Get visit basic info
    $sql = "SELECT v.*, o.name as outlet_name, u.full_name as auditor_name
            FROM visits v
            LEFT JOIN outlets o ON v.outlet_id = o.id
            LEFT JOIN users u ON v.user_id = u.id
            WHERE v.id = :visit_id";
    
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':visit_id', $visitId);
    $stmt->execute();
    $visit = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$visit) {
        Response::error('Visit not found', 404);
    }
    
    // Get checklist responses with category info
    $sql = "SELECT 
                vcr.id,
                vcr.visit_id,
                vcr.checklist_item_id,
                vcr.response,
                vcr.notes,
                cp.question,
                cp.id as point_id,
                cc.name as category_name,
                cc.id as category_id
            FROM visit_checklist_responses vcr
            INNER JOIN checklist_points cp ON vcr.checklist_item_id = cp.id
            INNER JOIN checklist_categories cc ON cp.category_id = cc.id
            WHERE vcr.visit_id = :visit_id
            ORDER BY cc.sort_order, cp.sort_order";
    
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':visit_id', $visitId);
    $stmt->execute();
    $responses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get photos
    $sql = "SELECT 
                id,
                visit_id,
                checklist_item_id,
                photo_path
            FROM visit_photos
            WHERE visit_id = :visit_id
            ORDER BY checklist_item_id, id";
    
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':visit_id', $visitId);
    $stmt->execute();
    $photos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Construct response
    $result = [
        'visit' => $visit,
        'responses' => $responses,
        'photos' => $photos
    ];
    
    Response::success($result);
    
} catch (Exception $e) {
    Response::error('Server error: ' . $e->getMessage(), 500);
}
?>
