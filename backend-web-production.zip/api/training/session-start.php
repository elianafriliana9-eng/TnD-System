<?php
/**
 * Start Training Session API
 * Create new training session
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/Response.php';
require_once __DIR__ . '/../../utils/Auth.php';
require_once __DIR__ . '/../../utils/Headers.php';

Headers::setAPIHeaders();

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Temporarily disabled for testing
// if (!Auth::checkAuth()) {
//     Response::unauthorized('Authentication required');
// }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Response::error('Method not allowed', 405);
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (!isset($data['outlet_id']) || !isset($data['checklist_id'])) {
        Response::error('Outlet ID and Checklist ID required', 400);
    }
    
    $db = Database::getInstance()->getConnection();
    
    // Get trainer_id from request or session
    $trainerId = $data['trainer_id'] ?? ($_SESSION['user_id'] ?? null);
    
    if (!$trainerId) {
        Response::error('Trainer ID required', 400);
    }
    
    // Check if trainer exists
    $stmt = $db->prepare("SELECT role FROM users WHERE id = :id");
    $stmt->execute([':id' => $trainerId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        Response::error('Trainer not found', 404);
    }
    
    // Create training session
    $sql = "INSERT INTO training_sessions 
            (outlet_id, trainer_id, checklist_id, session_date, start_time, status, notes)
            VALUES 
            (:outlet_id, :trainer_id, :checklist_id, :session_date, :start_time, 'ongoing', :notes)";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([
        ':outlet_id' => $data['outlet_id'],
        ':trainer_id' => $trainerId,
        ':checklist_id' => $data['checklist_id'],
        ':session_date' => $data['session_date'] ?? date('Y-m-d'),
        ':start_time' => $data['start_time'] ?? date('H:i:s'),
        ':notes' => $data['notes'] ?? null
    ]);
    
    $sessionId = $db->lastInsertId();
    
    // Get created session details
    $sql = "SELECT 
                ts.*,
                o.name as outlet_name,
                u.name as trainer_name,
                tc.name as checklist_name
            FROM training_sessions ts
            LEFT JOIN outlets o ON ts.outlet_id = o.id
            LEFT JOIN users u ON ts.trainer_id = u.id
            LEFT JOIN training_checklists tc ON ts.checklist_id = tc.id
            WHERE ts.id = :id";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([':id' => $sessionId]);
    $session = $stmt->fetch(PDO::FETCH_ASSOC);
    
    Response::success([
        'message' => 'Training session started successfully',
        'session' => $session
    ], 201);
    
} catch (Exception $e) {
    Response::error('Server error: ' . $e->getMessage(), 500);
}
