<?php
/**
 * Visit Model
 */

class Visit {
    private $db;
    private $table = 'visits';

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Create new visit
     */
    public function create($data) {
        $sql = "INSERT INTO {$this->table} 
                (outlet_id, user_id, visit_date, status, notes, started_at) 
                VALUES 
                (:outlet_id, :user_id, :visit_date, :status, :notes, :started_at)";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':outlet_id', $data['outlet_id']);
        $stmt->bindParam(':user_id', $data['user_id']);
        $stmt->bindParam(':visit_date', $data['visit_date']);
        $stmt->bindParam(':status', $data['status']);
        $stmt->bindParam(':notes', $data['notes']);
        $stmt->bindParam(':started_at', $data['started_at']);
        
        if ($stmt->execute()) {
            return $this->db->lastInsertId();
        }
        return false;
    }

    /**
     * Update visit
     */
    public function update($id, $data) {
        $sql = "UPDATE {$this->table} SET ";
        $fields = [];
        $params = [':id' => $id];

        foreach ($data as $key => $value) {
            $fields[] = "{$key} = :{$key}";
            $params[":{$key}"] = $value;
        }

        $sql .= implode(', ', $fields) . " WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        
        return $stmt->execute($params);
    }

    /**
     * Get visit by ID
     */
    public function findById($id) {
        $sql = "SELECT v.*, 
                o.name AS outlet_name, o.address AS outlet_location,
                u.name AS user_name
                FROM {$this->table} v
                LEFT JOIN outlets o ON v.outlet_id = o.id
                LEFT JOIN users u ON v.user_id = u.id
                WHERE v.id = :id";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Get visits by user
     */
    public function findByUser($userId, $limit = 100) {
        $sql = "SELECT v.*, 
                o.name AS outlet_name, o.address AS outlet_location
                FROM {$this->table} v
                LEFT JOIN outlets o ON v.outlet_id = o.id
                WHERE v.user_id = :user_id
                ORDER BY v.visit_date DESC
                LIMIT :limit";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get visits by outlet
     */
    public function findByOutlet($outletId, $limit = 50) {
        $sql = "SELECT v.*, 
                u.name AS user_name
                FROM {$this->table} v
                LEFT JOIN users u ON v.user_id = u.id
                WHERE v.outlet_id = :outlet_id
                ORDER BY v.visit_date DESC
                LIMIT :limit";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':outlet_id', $outletId);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get visit with full details (checklist responses and photos)
     */
    public function getVisitDetails($visitId) {
        $visit = $this->findById($visitId);
        if (!$visit) {
            return null;
        }

        // Get checklist responses
        $sql = "SELECT vcr.*, ci.item_text 
                FROM visit_checklist_responses vcr
                LEFT JOIN checklist_items ci ON vcr.checklist_item_id = ci.id
                WHERE vcr.visit_id = :visit_id
                ORDER BY ci.item_order ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':visit_id', $visitId);
        $stmt->execute();
        $visit['responses'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Get photos
        $sql = "SELECT vp.*, ci.item_text 
                FROM visit_photos vp
                LEFT JOIN checklist_items ci ON vp.checklist_item_id = ci.id
                WHERE vp.visit_id = :visit_id
                ORDER BY vp.uploaded_at ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':visit_id', $visitId);
        $stmt->execute();
        $visit['photos'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $visit;
    }

    /**
     * Save checklist response
     */
    public function saveChecklistResponse($data) {
        $sql = "INSERT INTO visit_checklist_responses 
                (visit_id, checklist_item_id, response, notes) 
                VALUES 
                (:visit_id, :checklist_item_id, :response, :notes)
                ON DUPLICATE KEY UPDATE 
                response = VALUES(response), 
                notes = VALUES(notes)";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':visit_id', $data['visit_id']);
        $stmt->bindParam(':checklist_item_id', $data['checklist_item_id']);
        $stmt->bindParam(':response', $data['response']);
        $stmt->bindParam(':notes', $data['notes']);
        
        return $stmt->execute();
    }

    /**
     * Save visit photo
     */
    public function savePhoto($data) {
        $sql = "INSERT INTO visit_photos 
                (visit_id, checklist_item_id, photo_path, description) 
                VALUES 
                (:visit_id, :checklist_item_id, :photo_path, :description)";
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':visit_id', $data['visit_id']);
        $stmt->bindParam(':checklist_item_id', $data['checklist_item_id']);
        $stmt->bindParam(':photo_path', $data['photo_path']);
        $stmt->bindParam(':description', $data['description']);
        
        if ($stmt->execute()) {
            return $this->db->lastInsertId();
        }
        return false;
    }
}
?>
