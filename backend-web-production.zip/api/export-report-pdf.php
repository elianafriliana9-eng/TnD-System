<?php
/**
 * Export Report PDF API
 * Get complete data for PDF generation
 * 
 * Endpoints:
 * GET /api/export-report-pdf.php?user_id={id}&report_type={type}&start_date={date}&end_date={date}&outlet_id={id}
 * report_type: overview | outlet | outlet_detail
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../classes/Database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get parameters
$userId = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$reportType = isset($_GET['report_type']) ? $_GET['report_type'] : 'overview';
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : null;
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : null;
$outletId = isset($_GET['outlet_id']) ? intval($_GET['outlet_id']) : null;

if ($userId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'User ID is required']);
    exit;
}

try {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Get user info
    $stmt = $conn->prepare("
        SELECT u.id, u.full_name, u.email, d.division_name
        FROM users u
        LEFT JOIN divisions d ON u.division_id = d.id
        WHERE u.id = ?
    ");
    $stmt->execute([$userId]);
    $userInfo = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$userInfo) {
        throw new Exception("User not found");
    }
    
    $response = [
        'success' => true,
        'report_type' => $reportType,
        'generated_at' => date('Y-m-d H:i:s'),
        'user' => [
            'id' => intval($userInfo['id']),
            'name' => $userInfo['full_name'],
            'email' => $userInfo['email'],
            'division' => $userInfo['division_name']
        ],
        'filters' => [
            'start_date' => $startDate,
            'end_date' => $endDate
        ],
        'data' => []
    ];
    
    // Build date filter
    $dateFilter = "";
    $params = [$userId];
    
    if ($startDate && $endDate) {
        // Use DATE() to compare only date part, ignoring time
        $dateFilter = " AND DATE(v.visit_date) BETWEEN ? AND ?";
        $params[] = $startDate;
        $params[] = $endDate;
    } elseif ($startDate) {
        $dateFilter = " AND DATE(v.visit_date) >= ?";
        $params[] = $startDate;
    } elseif ($endDate) {
        $dateFilter = " AND DATE(v.visit_date) <= ?";
        $params[] = $endDate;
    }
    
    if ($reportType === 'overview') {
        // Get overview statistics
        $stmt = $conn->prepare("
            SELECT 
                COUNT(DISTINCT v.id) as total_visits,
                COUNT(DISTINCT v.outlet_id) as total_outlets,
                SUM(CASE WHEN vcr.response = 'ok' THEN 1 ELSE 0 END) as ok_count,
                SUM(CASE WHEN vcr.response = 'not_ok' THEN 1 ELSE 0 END) as nok_count,
                SUM(CASE WHEN vcr.response = 'na' THEN 1 ELSE 0 END) as na_count
            FROM visits v
            LEFT JOIN visit_checklist_responses vcr ON v.id = vcr.visit_id
            WHERE v.user_id = ? AND v.status = 'completed' {$dateFilter}
        ");
        $stmt->execute($params);
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $okCount = intval($stats['ok_count']);
        $nokCount = intval($stats['nok_count']);
        $totalWithoutNA = $okCount + $nokCount;
        
        $response['data']['statistics'] = [
            'total_visits' => intval($stats['total_visits']),
            'total_outlets' => intval($stats['total_outlets']),
            'ok_count' => $okCount,
            'nok_count' => $nokCount,
            'na_count' => intval($stats['na_count']),
            'ok_percentage' => $totalWithoutNA > 0 ? round(($okCount / $totalWithoutNA) * 100, 1) : 0,
            'nok_percentage' => $totalWithoutNA > 0 ? round(($nokCount / $totalWithoutNA) * 100, 1) : 0
        ];
        
        // Get all outlets summary for PDF
        $stmt = $conn->prepare("
            SELECT 
                o.name as outlet_name,
                COUNT(DISTINCT v.id) as visits,
                SUM(CASE WHEN vcr.response = 'ok' THEN 1 ELSE 0 END) as ok_count,
                SUM(CASE WHEN vcr.response = 'not_ok' THEN 1 ELSE 0 END) as nok_count
            FROM outlets o
            INNER JOIN visits v ON o.id = v.outlet_id
            LEFT JOIN visit_checklist_responses vcr ON v.id = vcr.visit_id
            WHERE v.user_id = ? AND v.status = 'completed' {$dateFilter}
            GROUP BY o.id, o.name
            ORDER BY o.name
        ");
        $stmt->execute($params);
        $outlets = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $response['data']['outlets'] = array_map(function($outlet) {
            $ok = intval($outlet['ok_count']);
            $nok = intval($outlet['nok_count']);
            $total = $ok + $nok;
            $percent = $total > 0 ? round(($ok / $total) * 100, 1) : 0;
            
            return [
                'outlet_name' => $outlet['outlet_name'],
                'visits' => intval($outlet['visits']),
                'ok_count' => $ok,
                'nok_count' => $nok,
                'ok_percentage' => $percent,
                'status' => $percent >= 85 ? 'Good' : ($percent >= 70 ? 'Warning' : 'Critical')
            ];
        }, $outlets);
        
    } elseif ($reportType === 'outlet' || $reportType === 'outlet_detail') {
        // Get outlet-specific report
        if ($outletId <= 0) {
            throw new Exception("Outlet ID is required for outlet report");
        }
        
        // Get outlet info
        $stmt = $conn->prepare("SELECT * FROM outlets WHERE id = ?");
        $stmt->execute([$outletId]);
        $outletInfo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$outletInfo) {
            throw new Exception("Outlet not found");
        }
        
        $response['data']['outlet'] = [
            'id' => intval($outletInfo['id']),
            'name' => $outletInfo['outlet_name'],
            'address' => $outletInfo['address'],
            'city' => $outletInfo['city']
        ];
        
        // Get visit history for this outlet
        $stmt = $conn->prepare("
            SELECT 
                v.id,
                v.visit_date,
                v.status,
                COUNT(vcr.id) as total_items,
                SUM(CASE WHEN vcr.response = 'ok' THEN 1 ELSE 0 END) as ok_count,
                SUM(CASE WHEN vcr.response = 'not_ok' THEN 1 ELSE 0 END) as nok_count
            FROM visits v
            LEFT JOIN visit_checklist_responses vcr ON v.id = vcr.visit_id
            WHERE v.outlet_id = ? AND v.user_id = ? {$dateFilter}
            GROUP BY v.id, v.visit_date, v.status
            ORDER BY v.visit_date DESC
        ");
        
        $visitParams = [$outletId, $userId];
        if ($startDate && $endDate) {
            $visitParams[] = $startDate;
            $visitParams[] = $endDate;
        } elseif ($startDate) {
            $visitParams[] = $startDate;
        } elseif ($endDate) {
            $visitParams[] = $endDate;
        }
        
        $stmt->execute($visitParams);
        $visits = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $response['data']['visits'] = array_map(function($visit) {
            $ok = intval($visit['ok_count']);
            $nok = intval($visit['nok_count']);
            $total = $ok + $nok;
            $percent = $total > 0 ? round(($ok / $total) * 100, 1) : 0;
            
            return [
                'visit_id' => intval($visit['id']),
                'visit_date' => $visit['visit_date'],
                'status' => $visit['status'],
                'total_items' => $total,
                'ok_count' => $ok,
                'nok_count' => $nok,
                'ok_percentage' => $percent
            ];
        }, $visits);
        
        // Get NOK findings summary
        $stmt = $conn->prepare("
            SELECT 
                cp.question as checklist_point,
                cc.name as category_name,
                COUNT(*) as nok_frequency
            FROM visit_checklist_responses vcr
            JOIN visits v ON vcr.visit_id = v.id
            JOIN checklist_points cp ON vcr.checklist_item_id = cp.id
            JOIN checklist_categories cc ON cp.category_id = cc.id
            WHERE v.outlet_id = ? 
                AND v.user_id = ? 
                AND v.status = 'completed'
                AND vcr.response = 'not_ok'
                {$dateFilter}
            GROUP BY cp.question, cc.name
            ORDER BY nok_frequency DESC
            LIMIT 10
        ");
        $stmt->execute($visitParams);
        $nokIssues = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $response['data']['top_nok_issues'] = array_map(function($issue) {
            return [
                'point' => $issue['checklist_point'],
                'category' => $issue['category_name'],
                'frequency' => intval($issue['nok_frequency'])
            ];
        }, $nokIssues);
    }
    
    echo json_encode($response, JSON_PRETTY_PRINT);
    
} catch (PDOException $e) {
    error_log("Database error in export-report-pdf.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error occurred',
        'error' => $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log("Error in export-report-pdf.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
