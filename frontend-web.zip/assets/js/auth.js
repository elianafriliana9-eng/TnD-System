// Authentication management for admin panel
let currentUser = null;

document.addEventListener('DOMContentLoaded', function() {
    console.log('🔍 DOM loaded, checking auth status...');
    checkAuthStatus();
});

async function checkAuthStatus() {
    console.log('🔑 Checking authentication status...');
    try {
        const response = await AuthAPI.me();
        console.log('🔑 Auth response:', response);
        
        if (response.success) {
            currentUser = response.data;
            updateUserInfo();
            console.log('✅ User authenticated, showing dashboard...');
            showDashboard(); // Show default page
        } else {
            console.log('❌ User not authenticated, redirecting to login...');
            redirectToLogin();
        }
    } catch (error) {
        console.error('❌ Auth check failed:', error);
        redirectToLogin();
    }
}

function updateUserInfo() {
    const userNameElement = document.getElementById('user-name');
    if (userNameElement && currentUser) {
        userNameElement.textContent = currentUser.name;
    }
}

function redirectToLogin() {
    window.location.href = 'login.html';
}

async function logout() {
    try {
        const result = await Swal.fire({
            title: 'Are you sure?',
            text: 'You will be logged out from the system',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, logout!'
        });

        if (result.isConfirmed) {
            await AuthAPI.logout();
            localStorage.removeItem('user');
            
            Swal.fire({
                icon: 'success',
                title: 'Logged out!',
                text: 'You have been successfully logged out',
                timer: 2000,
                showConfirmButton: false
            }).then(() => {
                redirectToLogin();
            });
        }
    } catch (error) {
        console.error('Logout failed:', error);
        // Force redirect even if API call fails
        redirectToLogin();
    }
}

function showProfile() {
    if (!currentUser) return;
    
    const modalHTML = `
        <div class="modal fade" id="profileModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-user me-2"></i>User Profile
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form id="profileForm">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="profileName" value="${currentUser.name}" required>
                                <label for="profileName">Full Name</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="email" class="form-control" id="profileEmail" value="${currentUser.email}" required>
                                <label for="profileEmail">Email</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="profilePhone" value="${currentUser.phone || ''}" placeholder="Phone">
                                <label for="profilePhone">Phone</label>
                            </div>
                            <div class="form-floating mb-3">
                                <select class="form-select" id="profileRole" disabled>
                                    <option value="super_admin" ${currentUser.role === 'super_admin' ? 'selected' : ''}>Super Admin</option>
                                    <option value="admin" ${currentUser.role === 'admin' ? 'selected' : ''}>Admin</option>
                                    <option value="supervisor" ${currentUser.role === 'supervisor' ? 'selected' : ''}>Supervisor</option>
                                    <option value="auditor" ${currentUser.role === 'auditor' ? 'selected' : ''}>Auditor</option>
                                </select>
                                <label for="profileRole">Role</label>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="updateProfile()">Update Profile</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('modal-container').innerHTML = modalHTML;
    const modal = new bootstrap.Modal(document.getElementById('profileModal'));
    modal.show();
}

async function updateProfile() {
    const name = document.getElementById('profileName').value;
    const email = document.getElementById('profileEmail').value;
    const phone = document.getElementById('profilePhone').value;
    
    try {
        const response = await UsersAPI.update(currentUser.id, {
            name: name,
            email: email,
            phone: phone
        });
        
        if (response.success) {
            currentUser = response.data;
            updateUserInfo();
            
            const modal = bootstrap.Modal.getInstance(document.getElementById('profileModal'));
            modal.hide();
            
            showSuccess('Profile updated successfully');
        }
    } catch (error) {
        showErrorAlert(error.message || 'Failed to update profile');
    }
}

function showChangePassword() {
    const modalHTML = `
        <div class="modal fade" id="changePasswordModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-key me-2"></i>Change Password
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form id="changePasswordForm">
                            <div class="form-floating mb-3">
                                <input type="password" class="form-control" id="currentPassword" required>
                                <label for="currentPassword">Current Password</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="password" class="form-control" id="newPassword" required minlength="6">
                                <label for="newPassword">New Password</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="password" class="form-control" id="confirmPassword" required minlength="6">
                                <label for="confirmPassword">Confirm New Password</label>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="changePassword()">Change Password</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('modal-container').innerHTML = modalHTML;
    const modal = new bootstrap.Modal(document.getElementById('changePasswordModal'));
    modal.show();
}

async function changePassword() {
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    if (newPassword !== confirmPassword) {
        showErrorAlert('New password confirmation does not match');
        return;
    }
    
    try {
        const response = await AuthAPI.changePassword(currentPassword, newPassword, confirmPassword);
        
        if (response.success) {
            const modal = bootstrap.Modal.getInstance(document.getElementById('changePasswordModal'));
            modal.hide();
            
            showSuccess('Password changed successfully');
        }
    } catch (error) {
        showErrorAlert(error.message || 'Failed to change password');
    }
}