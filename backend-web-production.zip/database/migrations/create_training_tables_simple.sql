-- ============================================
-- INHOUSE TRAINING MODULE - DATABASE SCHEMA
-- Date: 20 Oktober 2025
-- Version: 1.0 - Simple Version (No Users Table Modification)
-- ============================================

-- 1. Training Checklists Table
CREATE TABLE IF NOT EXISTS training_checklists (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_active (is_active),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Training Categories Table
CREATE TABLE IF NOT EXISTS training_categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    checklist_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    order_index INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (checklist_id) REFERENCES training_checklists(id) ON DELETE CASCADE,
    INDEX idx_checklist (checklist_id),
    INDEX idx_order (order_index)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Training Points Table
CREATE TABLE IF NOT EXISTS training_points (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_id INT NOT NULL,
    question TEXT NOT NULL,
    order_index INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES training_categories(id) ON DELETE CASCADE,
    INDEX idx_category (category_id),
    INDEX idx_order (order_index)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Training Sessions Table
CREATE TABLE IF NOT EXISTS training_sessions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    outlet_id INT NOT NULL,
    trainer_id INT NOT NULL,
    checklist_id INT NOT NULL,
    session_date DATE NOT NULL,
    start_time TIME,
    end_time TIME,
    total_staff INT DEFAULT 0,
    average_score DECIMAL(3,1) DEFAULT 0,
    status ENUM('scheduled', 'ongoing', 'completed', 'cancelled') DEFAULT 'scheduled',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (outlet_id) REFERENCES outlets(id) ON DELETE RESTRICT,
    FOREIGN KEY (trainer_id) REFERENCES users(id) ON DELETE RESTRICT,
    FOREIGN KEY (checklist_id) REFERENCES training_checklists(id) ON DELETE RESTRICT,
    INDEX idx_outlet (outlet_id),
    INDEX idx_trainer (trainer_id),
    INDEX idx_date (session_date),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Training Participants Table
CREATE TABLE IF NOT EXISTS training_participants (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    staff_name VARCHAR(255) NOT NULL,
    position VARCHAR(100),
    phone VARCHAR(20),
    average_score DECIMAL(3,1) DEFAULT 0,
    notes TEXT,
    signature_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES training_sessions(id) ON DELETE CASCADE,
    INDEX idx_session (session_id),
    INDEX idx_name (staff_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Training Responses Table
CREATE TABLE IF NOT EXISTS training_responses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    training_point_id INT NOT NULL,
    participant_id INT,
    score INT CHECK (score BETWEEN 1 AND 5),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES training_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (training_point_id) REFERENCES training_points(id) ON DELETE RESTRICT,
    FOREIGN KEY (participant_id) REFERENCES training_participants(id) ON DELETE SET NULL,
    INDEX idx_session (session_id),
    INDEX idx_point (training_point_id),
    INDEX idx_participant (participant_id),
    UNIQUE KEY unique_response (session_id, training_point_id, participant_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Training Photos Table
CREATE TABLE IF NOT EXISTS training_photos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    training_point_id INT,
    photo_path VARCHAR(255) NOT NULL,
    caption TEXT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES training_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (training_point_id) REFERENCES training_points(id) ON DELETE SET NULL,
    INDEX idx_session (session_id),
    INDEX idx_point (training_point_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- SUCCESS MESSAGE
-- ============================================

SELECT 'Training tables created successfully!' AS status;
