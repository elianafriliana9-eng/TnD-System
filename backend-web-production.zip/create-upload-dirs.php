<?php
/**
 * Create Upload Directories
 * Run this script once to create all upload directories with proper permissions
 */

// Base upload directory
$baseDir = __DIR__ . '/uploads';

// All required upload directories
$directories = [
    $baseDir,
    $baseDir . '/visit_photos',
    $baseDir . '/training/photos',
    $baseDir . '/profile_photos',
];

echo "Creating upload directories...\n\n";

foreach ($directories as $dir) {
    if (!file_exists($dir)) {
        if (mkdir($dir, 0777, true)) {
            echo "✓ Created: $dir\n";
        } else {
            echo "✗ Failed to create: $dir\n";
        }
    } else {
        echo "✓ Already exists: $dir\n";
    }
    
    // Ensure writable
    if (!is_writable($dir)) {
        chmod($dir, 0777);
        echo "  → Set permissions to 0777\n";
    }
}

echo "\n=== Summary ===\n";
echo "Base directory: " . realpath($baseDir) . "\n";
echo "All directories created and writable!\n";
echo "\nYou can now upload photos.\n";
?>
