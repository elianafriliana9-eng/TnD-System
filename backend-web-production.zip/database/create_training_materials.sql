-- Create training_materials table
CREATE TABLE IF NOT EXISTS training_materials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    file_path VARCHAR(255) NOT NULL,
    file_type VARCHAR(50),
    file_size INT,
    thumbnail_path VARCHAR(255),
    uploaded_by INT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_uploaded_at (uploaded_at),
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample data (optional)
INSERT INTO training_materials (title, description, category, file_path, file_type, file_size) VALUES
('Panduan Hospitality Dasar', 'Materi training tentang hospitality dan pelayanan pelanggan', 'hospitality', '/uploads/sample/hospitality_guide.pdf', 'pdf', 1024000),
('Customer Service Excellence', 'Teknik-teknik pelayanan pelanggan yang excellent', 'customer_service', '/uploads/sample/customer_service.pdf', 'pdf', 2048000);

SELECT 'Training materials table created successfully!' as status;
