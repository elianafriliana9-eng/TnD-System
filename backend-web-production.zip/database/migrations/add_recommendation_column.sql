-- Add recommendation column to visit_checklist_responses table
-- This stores improvement recommendations for NOK findings

ALTER TABLE visit_checklist_responses 
ADD COLUMN recommendation TEXT NULL AFTER notes,
ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Update existing records to set updated_at
UPDATE visit_checklist_responses SET updated_at = CURRENT_TIMESTAMP WHERE updated_at IS NULL;

-- Add index for better query performance
CREATE INDEX idx_response_type ON visit_checklist_responses(response);
CREATE INDEX idx_visit_checklist ON visit_checklist_responses(visit_id, checklist_item_id);
