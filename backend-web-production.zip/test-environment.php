<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/utils/Response.php';

try {
    // Test Database Connection
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . 
        ";dbname=" . DB_NAME . 
        ";charset=" . DB_CHARSET,
        DB_USERNAME,
        DB_PASSWORD,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    // Test Environment Variables
    $envStatus = [
        'app_env' => APP_ENV,
        'app_debug' => APP_DEBUG ? 'true' : 'false',
        'app_url' => APP_URL,
        'db_connected' => true,
        'php_version' => PHP_VERSION,
        'server_software' => $_SERVER['SERVER_SOFTWARE'],
        'document_root' => $_SERVER['DOCUMENT_ROOT'],
        'script_filename' => $_SERVER['SCRIPT_FILENAME']
    ];
    
    Response::success($envStatus);
} catch (PDOException $e) {
    Response::error('Database connection failed: ' . $e->getMessage());
} catch (Exception $e) {
    Response::error('System error: ' . $e->getMessage());
}