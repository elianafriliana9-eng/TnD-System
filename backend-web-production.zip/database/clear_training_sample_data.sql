-- Clear all sample data from training module
-- Run this to remove all sample/dummy data and start fresh with real data

-- Delete in order to respect foreign key constraints

-- 1. Delete training responses (references sessions and points)
DELETE FROM training_responses WHERE session_id IN (SELECT id FROM training_sessions);

-- 2. Delete training photos (references sessions)
DELETE FROM training_photos WHERE session_id IN (SELECT id FROM training_sessions);

-- 3. Delete training participants (references sessions)
DELETE FROM training_participants WHERE session_id IN (SELECT id FROM training_sessions);

-- 4. Delete training sessions
DELETE FROM training_sessions;

-- 5. Delete training points (references categories)
DELETE tp FROM training_points tp 
INNER JOIN training_categories tc ON tp.category_id = tc.id;

-- 6. Delete training categories (references checklists)
DELETE FROM training_categories;

-- 7. Delete training checklists
DELETE FROM training_checklists;

-- 8. Delete training materials
DELETE FROM training_materials;

-- Reset auto increment (optional)
ALTER TABLE training_sessions AUTO_INCREMENT = 1;
ALTER TABLE training_checklists AUTO_INCREMENT = 1;
ALTER TABLE training_categories AUTO_INCREMENT = 1;
ALTER TABLE training_points AUTO_INCREMENT = 1;
ALTER TABLE training_materials AUTO_INCREMENT = 1;
ALTER TABLE training_participants AUTO_INCREMENT = 1;
ALTER TABLE training_responses AUTO_INCREMENT = 1;
ALTER TABLE training_photos AUTO_INCREMENT = 1;

-- Verify all tables are empty
SELECT 'training_sessions' as tabel, COUNT(*) as jumlah FROM training_sessions
UNION ALL SELECT 'training_checklists', COUNT(*) FROM training_checklists
UNION ALL SELECT 'training_categories', COUNT(*) FROM training_categories
UNION ALL SELECT 'training_points', COUNT(*) FROM training_points
UNION ALL SELECT 'training_materials', COUNT(*) FROM training_materials
UNION ALL SELECT 'training_participants', COUNT(*) FROM training_participants
UNION ALL SELECT 'training_responses', COUNT(*) FROM training_responses
UNION ALL SELECT 'training_photos', COUNT(*) FROM training_photos;

SELECT 'All training sample data cleared successfully!' as status;
